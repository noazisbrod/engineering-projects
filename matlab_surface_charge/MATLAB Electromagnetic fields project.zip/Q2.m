%%q2a1
v_0 = 1;
R = 0.5;
N = 1000;
a = 30;
z1 = 3;
z2 = 1;
z3 = 5;
z4 = 2;
z5 = 4;
z6 = 1;
z7 = 4;
z8 = 1;
z9 = 4;
h = 5*(1+0.05*((z4/4.5)-1));
d = 4*(1+0.05*((z7-z5)/9));
epsi0 = 8.85*10^-12;
d_m = 2 * pi * R/N;
z = zeros(5*N+4,5*N+4);
phi_an = zeros(1,N);
voltage = zeros(1,N);
for m=1:N
    phi_an(m) = (m*2*pi/N);
end
for i = 1:5
    for j=1:5
        for k=1:N
            for l=1:N
                if k~=l || i~=j
                    r = [(i-3)*d+R*cos(phi_an(1,k)) h+R*sin(phi_an(k))];
                    r_tag_image = [(j-3)*d+R*cos(phi_an(1,l)) -(h+R*sin(phi_an(1,l)))]; %point on imaged cylinder
                    r_tag = [(j-3)*d+R*cos(phi_an(1,l)) (h+R*sin(phi_an(1,l)))]; %point on cylinder
                    G = -1/(2*pi*epsi0)*log(abs(norm(r-r_tag))./abs(norm(r-r_tag_image)));
                    z((i-1)*N+k,(j-1)*N+l) = d_m .* G;
                end
                 if k==l && i==j
                 r_tag_image = [R*cos(phi_an(1,l)) -(h+R*sin(phi_an(1,l)))];
                 r = [R*cos(phi_an(1,k)) h+R*sin(phi_an(k))];
                 z((i-1)*N+k,(j-1)*N+l) = -d_m/(2*pi*epsi0)*(log(d_m/2*a)-1)-d_m/(2*pi*epsi0)*log(abs(norm(r-r_tag_image))/a);
                end
        
            end
        end
    end
end
electrodes = []; 
c = 3;
for m = 1:5
    if m~=c
        electrodes = [electrodes m]; %#ok
    end
end
for n = 5*N+1:5*N+4
    for m = electrodes(n-5*N)*N-(N-1):electrodes(n-5*N)*N
        z(n,m) = d_m;
        z(m,n) = -1;
    end
end
voltage_new = zeros(5*N+4,1);
for m= c*N-(N-1):c*N
    voltage_new(m) = v_0;
end
etta_new = linsolve(z,voltage_new);
real_etta = etta_new(1:5*N);
v_etta = etta_new(5*N+1:5*N+4);
x = linspace(-15,15,300);
y = linspace(0,10,100);
potential_2 = zeros(300,100);
for i = 1:5
    for m=1:1000
        for k=1:300
            for l=1:100
              r_cart = [x(1,k) y(1,l)];
              r_tagb = [(i-3)*d+R*cos(phi_an(m)) h+R*sin(phi_an(m))];
              r_tagb_image = [(i-3)*d+R*cos(phi_an(m)) -1*(h+R*sin(phi_an(m)))];
              G = -1/(2*pi*epsi0) * log(abs(norm(r_cart-r_tagb))./abs(norm(r_cart-r_tagb_image)));
              potential_2(k,l) = potential_2(k,l)+real_etta((i-1)*N+m,1)*d_m*G;
            end     
        end
    end
end
[X,Y] = meshgrid(x,y);
figure;
contour(X,Y,potential_2',100);
xlabel('[m]');
ylabel('[m]');
title('Electric Field as a function of space');
colorbar
hold on
[field_x,field_y] = gradient(potential_2');
quiver(X,Y,-field_x,-field_y);
xlabel('[m]');
ylabel('[m]');
colorbar
title('Electric Potential as a function of space');
hold off
%%
%%q2a2
v_0 = 1;
R = 0.5;
N = 1000;
a = 30;
z1 = 3;
z2 = 1;
z3 = 5;
z4 = 2;
z5 = 4;
z6 = 1;
z7 = 4;
z8 = 1;
z9 = 4;
z = zeros(5*N+4,5*N+4);
h = 5*(1+0.05*((z4/4.5)-1));
d = 4*(1+0.05*((z7-z5)/9));
epsi0 = 8.85*10^-12;
d_m = 2 * pi * R/N;
M = zeros(5,5);
for m=1:N
    phi_an(m) = (m*2*pi/N);
end
for i = 1:5
    for j=1:5
        for k=1:N
            for l=1:N
                if k~=l || i~=j
                    r = [(i-3)*d+R*cos(phi_an(1,k)) h+R*sin(phi_an(k))];
                    r_tag_image = [(j-3)*d+R*cos(phi_an(1,l)) -(h+R*sin(phi_an(1,l)))]; %point on imaged cylinder
                    r_tag = [(j-3)*d+R*cos(phi_an(1,l)) (h+R*sin(phi_an(1,l)))]; %point on cylinder
                    G = -1/(2*pi*epsi0)*log(abs(norm(r-r_tag))./abs(norm(r-r_tag_image)));
                    z((i-1)*N+k,(j-1)*N+l) = d_m .* G;
                end
                if k==l && i==j
                    r_tag_image = [R*cos(phi_an(1,l)) -(h+R*sin(phi_an(1,l)))];
                    r = [R*cos(phi_an(1,k)) h+R*sin(phi_an(k))];
                    z((i-1)*N+k,(j-1)*N+l) = -d_m/(2*pi*epsi0)*(log(d_m/2*a)-1)-d_m/(2*pi*epsi0)*log(abs(norm(r-r_tag_image))/a);
                end
        
            end
        end
    end
end
for c = 1:5 %%given the index of which electrode is connected to source, etta and voltage will be calculated
    electrodes = [];
    for m = 1:5
        if m~=c
            electrodes = [electrodes m]; %#ok
        end
    end
    for n = 5*N+1:5*N+4
        for m = 1:5*N+4
            z(n,m) = 0;
            z(m,n) = 0;
        end
    end
    for n = 5*N+1:5*N+4
        for m = electrodes(n-5*N)*N-(N-1):electrodes(n-5*N)*N
            z(n,m) = d_m;
            z(m,n) = -1;
        end
    end
    voltage_new = zeros(5*N+4,1);
    for m= c*N-(N-1):c*N
        voltage_new(m) = v_0;
    end
    etta_new = linsolve(z,voltage_new);
real_etta = etta_new(1:5*N);
v_etta = etta_new(5*N+1:5*N+4);
M(c,electrodes) = v_etta;
M(c,c) = v_0;
end
%%
%q2b1
R0 = 0.8;
R = 0.5;
N = 1000;
a=30;
v_0 =1;
z1 = 3;
z2 = 1;
z3 = 5;
z4 = 2;
z5 = 4;
z6 = 1;
z7 = 4;
z8 = 1;
z9 = 4;
h = 5*(1+0.05*((z4/4.5)-1));
d = 4*(1+0.05*((z7-z5)/9));
x0 = z3/1.5 - 3;
y0 = 2.75*(1+0.05*sign(z8-z6)*z3/9);
x1 = [-2*d -d 0 d 2*d x0];
y1 = [h h h h h y0];
R1 = [R R R R R R0];
d_mb = zeros(1,6);
for i = 1:6
    d_mb(i) = 2 * pi * R1(i)/N;
end
epsi0 = 8.85*10^-12;
z = zeros(6*N+5,6*N+5);
phi_an = zeros(1,N);
for m=1:N
    phi_an(m) = (m*2*pi/N);
end
voltage = zeros(1,N);
for m=1:N
    phi_an(m) = (m*2*pi/N);
end
for i = 1:6
    for j = 1:6
        for k=1:N
            for l=1:N
                if k~=l || i~=j
                    r = [x1(i)+R1(i)*cos(phi_an(1,k)) y1(i)+R1(i)*sin(phi_an(k))];
                    r_tag_image = [x1(j)+R1(j)*cos(phi_an(1,l)) -(y1(j)+R1(j)*sin(phi_an(1,l)))]; %point on imaged cylinder
                    r_tag = [x1(j)+R1(j)*cos(phi_an(1,l)) (y1(j)+R1(j)*sin(phi_an(1,l)))]; %point on cylinder
                    G = -1/(2*pi*epsi0)*log(abs(norm(r-r_tag))./abs(norm(r-r_tag_image)));
                    z((i-1)*N+k,(j-1)*N+l) = d_mb(j) .* G;
                end
                if k==l && i==j
                    r_tag_image = [R1(j)*cos(phi_an(1,l)) -(y1(j)+R1(j)*sin(phi_an(1,l)))];
                    r = [R1(i)*cos(phi_an(1,k)) y1(i)+R1(i)*sin(phi_an(k))];
                    z((i-1)*N+k,(j-1)*N+l) = -d_mb(j)/(2*pi*epsi0)*(log(d_mb(i)/2*a)-1)-d_mb(i)/(2*pi*epsi0)*log(abs(norm(r-r_tag_image))/a);
                end
            end
        end
    end
end
c = 3;
electrodes = [];
for m = 1:6
    if m~=c
        electrodes = [electrodes m]; %#ok
    end
end

for n = 6*N+1:6*N+5
    for m = electrodes(n-6*N)*N-(N-1):electrodes(n-6*N)*N
        z(n,m) = d_mb(electrodes(n-6*N));
        z(m,n) = -1;
    end
end
voltage_new = zeros(6*N+5,1);
for m= c*N-(N-1):c*N
    voltage_new(m) = v_0;
end
etta_new = linsolve(z,voltage_new);
real_etta = etta_new(1:6*N);
v_etta = etta_new(6*N+1:6*N+5);
x = linspace(-15,15,300);
y = linspace(0,10,100);
potential_2 = zeros(300,100);       
for i = 1:6
    for m=1:1000
        for k=1:300
            for l=1:100
              r_cart = [x(1,k) y(1,l)];
              r_tag = [x1(i)+R1(i)*cos(phi_an(m)) (y1(i)+R1(i)*sin(phi_an(m)))];
              r_tag_image = [x1(i)+R1(i)*cos(phi_an(m)) -(y1(i)+R1(i)*sin(phi_an(m)))];
              G = -1/(2*pi*epsi0) * log(abs(norm(r_cart-r_tag))./abs(norm(r_cart-r_tag_image)));
              potential_2(k,l) = potential_2(k,l)+real_etta((i-1)*N+m)*d_mb(i)*G;
            end     
        end
    end
end

figure;
[X,Y] = meshgrid(x,y);
contour(X,Y,potential_2',100);
hold on
[field_x,field_y] = gradient(potential_2');
quiver(X,Y,-field_x,-field_y)
colorbar
hold off
%%
%%q2b2
R0 = 0.8;
R = 0.5;
N = 1000;
a=30;
z1 = 3;
z2 = 1;
z3 = 5;
z4 = 2;
z5 = 4;
z6 = 1;
z7 = 4;
z8 = 1;
z9 = 4;
h = 5*(1+0.05*((z4/4.5)-1));
d = 4*(1+0.05*((z7-z5)/9));
x0 = z3/1.5 - 3;
y0 = 2.75*(1+0.05*sign(z8-z6)*z3/9);
x1 = [-2*d -d 0 d 2*d x0];
y1 = [h h h h h y0];
R1 = [R R R R R R0];
d_mb = zeros(1,6);
M_2 = zeros(6,6);
R0 = 0.8;
R = 0.5;
N = 1000;
a=30;
v_0 =1;
for i = 1:6
    d_mb(i) = 2 * pi * R1(i)/N;
end
epsi0 = 8.85*10^-12;
z = zeros(6*N+5,6*N+5);
phi_an = zeros(1,N);
for m=1:N
    phi_an(m) = (m*2*pi/N);
end
voltage = zeros(1,N);
for m=1:N
    phi_an(m) = (m*2*pi/N);
end
for i = 1:6
    for j = 1:6
        for k=1:N
            for l=1:N
                if k~=l || i~=j
                    r = [x1(i)+R1(i)*cos(phi_an(1,k)) y1(i)+R1(i)*sin(phi_an(k))];
                    r_tag_image = [x1(j)+R1(j)*cos(phi_an(1,l)) -(y1(j)+R1(j)*sin(phi_an(1,l)))]; %point on imaged cylinder
                    r_tag = [x1(j)+R1(j)*cos(phi_an(1,l)) (y1(j)+R1(j)*sin(phi_an(1,l)))]; %point on cylinder
                    G = -1/(2*pi*epsi0)*log(abs(norm(r-r_tag))./abs(norm(r-r_tag_image)));
                    z((i-1)*N+k,(j-1)*N+l) = d_mb(j) .* G;
                end
                if k==l && i==j
                    r_tag_image = [R1(j)*cos(phi_an(1,l)) -(y1(j)+R1(j)*sin(phi_an(1,l)))];
                    r = [R1(i)*cos(phi_an(1,k)) y1(i)+R1(i)*sin(phi_an(k))];
                    z((i-1)*N+k,(j-1)*N+l) = -d_mb(j)/(2*pi*epsi0)*(log(d_mb(i)/2*a)-1)-d_mb(i)/(2*pi*epsi0)*log(abs(norm(r-r_tag_image))/a);
                end
            end
        end
    end
end
for c = 1:6
    electrodes = [];
    for m = 1:6
        if m~=c
            electrodes = [electrodes m]; %#ok
        end
    end
    for n = 6*N+1:6*N+4
        for m = 1:6*N+4
            z(n,m) = 0;
            z(m,n) = 0;
        end
    end
    for n = 6*N+1:6*N+5
        for m = electrodes(n-6*N)*N-(N-1):electrodes(n-6*N)*N
            z(n,m) = d_mb(electrodes(n-6*N));
            z(m,n) = -1;
        end
    end
    voltage_new = zeros(6*N+5,1);
    for m= c*N-(N-1):c*N
        voltage_new(m) = v_0;
    end
    etta_new = linsolve(z,voltage_new);
    real_etta = etta_new(1:6*N);
    v_etta = etta_new(6*N+1:6*N+5);
    M_2(c,electrodes) = v_etta;
    M_2(c,c) = v_0;
    b_vector = M_2(1:5,6);
    final_M_2 = M_2(1:5,1:5);

end
%%