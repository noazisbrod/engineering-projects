%% q1a
v_0 = 1;
R = 0.5;
h = 5;
N = 1000;
a = 30;
epsi0 = 8.85*10^-12;
d_m = 2 * pi * R/N;
z = zeros(N);
phi_an = zeros(1,N);
voltage = zeros(1,N);
for m=1:N
    phi_an(m) = (m*2*pi/N);
end

for k=1:N
    for l=1:N
        if k~=l
            r = [R*cos(phi_an(1,k)) h+R*sin(phi_an(k))]; %point in space
            r_tag_image = [R*cos(phi_an(1,l)) -(h+R*sin(phi_an(1,l)))]; %point on imaged cylinder
            r_tag = [R*cos(phi_an(1,l)) (h+R*sin(phi_an(1,l)))]; %point on cylinder
            G = -1/(2*pi*epsi0) * log(abs(norm(r-r_tag))./abs(norm(r-r_tag_image)));
            z(k,l) = d_m .* G;
        end
        if k==l
            r_tag_image = [R*cos(phi_an(1,l)) -(h+R*sin(phi_an(1,l)))];
            r = [R*cos(phi_an(1,k)) h+R*sin(phi_an(k))];
            z(k,l) = -d_m/(2*pi*epsi0)*(log(d_m/2*a)-1)-d_m/(2*pi*epsi0)*log(abs(norm(r-r_tag_image))/a);
        end
        
    end
end

for k=1:N
    voltage(k) = v_0;
end
voltage = transpose(voltage);
etta = linsolve(z,voltage);
etta = transpose(etta);
plot(phi_an,etta)
xlabel('[rad]')
ylabel('[C/m^2]')
title('Surface charge density as a function of the angle phi')
%%
%%q1b
etta = transpose(etta);
x = linspace(-5,5,100);
y = linspace(0,10,100);
n_potential = zeros(100);
for m=1:1000
    for k=1:100
        for l=1:100
            r_cart = [x(1,l) y(1,k)];
            r_tagb = [R*cos(phi_an(m)) h+R*sin(phi_an(m))];
            r_tagb_image = [R*cos(phi_an(m)) -1*(h+R*sin(phi_an(m)))];
            G = -1/(2*pi*epsi0) * log(abs(norm(r_cart-r_tagb))./abs(norm(r_cart-r_tagb_image)));
            n_potential(k,l) = n_potential(k,l)+etta(m,1)*d_m*G;
        end     
    end
end
           
figure;
[X,Y] = meshgrid(x,y);
contour(X,Y,n_potential);
hold on
[field_x,field_y] = gradient(n_potential); %minus follows
quiver(X,Y,-field_x,-field_y)
title('Electric potential and field as a function of space');
xlabel('[m]');
ylabel('[m]');
colorbar;
hold off

